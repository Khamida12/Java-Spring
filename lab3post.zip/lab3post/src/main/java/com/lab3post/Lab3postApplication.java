package com.lab3post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab3postApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab3postApplication.class, args);
    }

}
