package com.lab3post.controller;

import java.util.List;
import com.lab3post.model.User;
import com.lab3post.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
public class UserController {

    @Autowired
    UserRepository userRepository;

    @PostMapping
    public String create(@RequestBody User user) {
        userRepository.save(user);
        return "User is created";
    }

    @GetMapping
    public List<User> getAllUsers(){
        List<User> users = userRepository.findAll();
        return users;
    }
}
