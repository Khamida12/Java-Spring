package com.example.lab_2;

import lombok.Data;
import java.util.List;

@Data
public class Hospital {
    private String name;
    private List<Doctor> doctors;
}
