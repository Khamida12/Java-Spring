package com.example.lab_2.web;

import com.example.lab_2.Doctor;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import javax.print.Doc;
import java.util.HashMap;
import java.util.Map;
import com.example.lab_2.Doctor.Qualification;

@Component
public class DoctorConverter implements Converter<String, Doctor> {
    private Map<String, Doctor> doctorMap = new HashMap<>();

    public DoctorConverter() {
        doctorMap.put("qwerty@gmail.com",
                new Doctor("Robert","Vlad",  "09:00-10:00", "87089996633", "qwerty@gmail.com", Qualification.DENTIST));
        doctorMap.put("j.snow@gmail.com",
                new Doctor("John", "Snow", "10:00-11:00", "87772223344", "j.snow@gmail.com", Qualification.DENTIST));
        doctorMap.put("j.duncan@gmail.com",
                new Doctor("Jade", "Duncan", "09:00-12:00", "87472345678", "j.duncan@gmail.com", Qualification.SURGEON));
        doctorMap.put("jerry@gmail.com",
                new Doctor("Jerry", "Howell", "14:00-17:00", "87717894567", "jerry@gmail.com", Qualification.SURGEON));
        doctorMap.put("neal@gmail.com",
                new Doctor("Neal", "Reyes", "09:00-10:00", "87773461368", "neal@gmail.com", Qualification.PEDIATRICIAN));
        doctorMap.put("selena.mann@gmail.com",
                new Doctor("Selena", "Mann",  "14:00-15:00", "87052391524", "selena.mann@gmail.com", Qualification.TRAUMATOLOGIST));
        doctorMap.put("osc.newton@gmail.com",
                new Doctor("Oscar", "Newton", "15:00-16:00", "87009134298", "osc.newton@gmail.com", Qualification.TRAUMATOLOGIST));
        doctorMap.put("alex.knight@gmail.com",
                new Doctor("Alexis", "Knight", "09:00-10:00", "87471396723", "alex.knight@gmail.com", Qualification.CARDIOLOGIST));
        doctorMap.put("silva.a@gmail.com",
                new Doctor("Adele", "Silva",   "16:00-17:00", "87769473503", "silva.a@gmail.com",Qualification.PSYCHIATRIST));
        doctorMap.put("meskill.j@gmail.com",
                new Doctor("Justin", "Meskill",  "17:00-18:00", "87764274891", "meskill.j@gmail.com", Qualification.PSYCHIATRIST));

}

    @Override
    public Doctor convert(String email) {
        return doctorMap.get(email);
    }

}

