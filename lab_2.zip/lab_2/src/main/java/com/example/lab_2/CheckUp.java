package com.example.lab_2;

import lombok.Data;

import javax.print.Doc;
import java.util.ArrayList;
import java.util.List;

@Data
public class CheckUp {
    private String id;
    private String description;
    private String patientName;
    private String patientSurname;
    private String patientAge;
    private String patientIIN;
    private String dateTime;

    private List<Hospital> hospitals = new ArrayList<>();

    public void addCheckUp(Hospital hospital) {
        this.hospitals.add(hospital);
    }
}
