package com.example.lab_2.web;

import com.example.lab_2.CheckUp;
import com.example.lab_2.Hospital;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.example.lab_2.Doctor.Qualification;
import com.example.lab_2.Doctor;

import javax.print.Doc;

@Slf4j
@Controller
@RequestMapping("/design")
@SessionAttributes("checkUp")

public class DesignCheckUpController {
    @ModelAttribute
    public void addCheckUpModel(Model model) {
        List<Doctor> doctors = Arrays.asList(
                new Doctor("Robert","Vlad",  "09:00-10:00", "87089996633", "qwerty@gmail.com", Qualification.DENTIST),
                new Doctor("John", "Snow", "10:00-11:00", "87772223344", "j.snow@gmail.com", Qualification.DENTIST),
                new Doctor("Jade", "Duncan", "09:00-12:00", "87472345678", "j.duncan@gmail.com", Qualification.SURGEON),
                new Doctor("Jerry", "Howell", "14:00-17:00", "87717894567", "jerry@gmail.com", Qualification.SURGEON),
                new Doctor("Neal", "Reyes", "09:00-10:00", "87773461368", "neal@gmail.com", Qualification.PEDIATRICIAN),
                new Doctor("Selena", "Mann",  "14:00-15:00", "87052391524", "selena.mann@gmail.com", Qualification.TRAUMATOLOGIST),
                new Doctor("Oscar", "Newton", "15:00-16:00", "87009134298", "osc.newton@gmail.com", Qualification.TRAUMATOLOGIST),
                new Doctor("Alexis", "Knight", "09:00-10:00", "87471396723", "alex.knight@gmail.com", Qualification.CARDIOLOGIST),
                new Doctor("Adele", "Silva",   "16:00-17:00", "87769473503", "silva.a@gmail.com",Qualification.PSYCHIATRIST),
                new Doctor("Justin", "Meskill",  "17:00-18:00", "87764274891", "meskill.j@gmail.com", Qualification.PSYCHIATRIST)

        );
        Qualification[] qualifications = Doctor.Qualification.values();
        for (Qualification qualification : qualifications) {
            model.addAttribute(qualification.toString().toLowerCase(),
                    filterByQualification(doctors, qualification));
        }
    }
    @ModelAttribute(name = "checkUp")
    public CheckUp checkUp() {
        return new CheckUp();
    }

    @ModelAttribute(name = "hospital")
    public Hospital hospital() {
        return new Hospital();
    }

    @GetMapping
    public String showDesignForm() {
        return "design";
    }

    @PostMapping
    public String processHospital(Hospital hospital,
                                  @ModelAttribute CheckUp checkUp) {
        checkUp.addCheckUp(hospital);
        log.info("Processing check up: {}", hospital);
        return "redirect:/allCheckUps/current";
    }

    private Iterable<Doctor> filterByQualification(
            List<Doctor> doctors, Qualification qualification) {
        return doctors
                .stream()
                .filter(x -> x.getQualification().equals(qualification))
                .collect(Collectors.toList());
    }
}
