package com.example.lab_2;

import lombok.Data;

@Data
public class Doctor {

    private final String name;
    private final String surname;
    private final String time;
    private final String phoneNumber;
    private final String email;
    private final Qualification qualification;

    public enum Qualification{
        DENTIST, SURGEON, PEDIATRICIAN, TRAUMATOLOGIST, CARDIOLOGIST, PSYCHIATRIST
    }
}

