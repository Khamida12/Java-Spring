package com.example.lab_2.web;

import com.example.lab_2.CheckUp;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

@Slf4j
@Controller
@RequestMapping("/allCheckUps")
@SessionAttributes("checkup")

public class CheckUpController {
    @GetMapping("/current")
    public String checkUpForm() {
        return "checkUpForm";
    }

    @PostMapping
    public String processCheckUp(CheckUp checkUp,
                                 SessionStatus sessionStatus) {
        log.info("Check up submitted: {}", checkUp);
        sessionStatus.setComplete();
        return "redirect:/";
    }
}
