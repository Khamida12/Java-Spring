package com.example.lab2_app.model;

import lombok.Data;

import java.util.List;

@Data
public class Hospital {

    private final String name;
    private final String description;
    private final int number;
    private final String address;
    private final String index;
    private final String contact;

    private final List<Patient> patientList;
}
