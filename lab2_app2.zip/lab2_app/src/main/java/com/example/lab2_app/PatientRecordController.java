package com.example.lab2_app;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PatientRecordController {

    @GetMapping("/")
    public String patientRecord(){
        return "patientRecord";
    }
}
