package com.example.lab2_app.model;

import com.example.lab2_app.model.Patient;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class RecordPatients {

    private String record;
    private String date;

    private List<Patient> patientList = new ArrayList<>();

    public void addPatient(Patient patient){
        this.patientList.add(patient);
    }
}

