package com.example.lab2_app.model;

import lombok.Data;

@Data
public class Record {

    private final String id;
    private final String description;
    private final String time;
    private final Qualification qualification;

    public enum Qualification{
        DENTIST, SURGEON, PEDIATRICIAN, TRAUMATOLOGIST, CARDIOLOGIST, PSYCHIATRIST
    }


}
