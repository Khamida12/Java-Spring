package com.example.lab2_app.web;


import com.example.lab2_app.model.RecordPatients;
import com.example.lab2_app.model.Patient;
import com.example.lab2_app.model.Record;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import com.example.lab2_app.model.Record.Qualification;



@Slf4j
@Controller
@RequestMapping("/design")
@SessionAttributes("recordPatients")

public class DesignPatientsController {
    @ModelAttribute
    public void addRecordToSchedule(Model model) {
        List<Record> records = Arrays.asList(
                new Record("1","record", "09:00-10:00",  Qualification.DENTIST),
                new Record("2", "record", "10:00-11:00",  Qualification.DENTIST),
                new Record("3", "record", "11:00-12:00",  Qualification.SURGEON),
                new Record("4", "record", "12:00-13:00",  Qualification.SURGEON),
                new Record("5", "record", "14:00-15:00",  Qualification.PEDIATRICIAN),
                new Record("6", "record", "15:00-16:00",  Qualification.TRAUMATOLOGIST),
                new Record("7", "record", "16:00-17:00",  Qualification.CARDIOLOGIST),
                new Record("8", "record", "17:00-19:00",  Qualification.PSYCHIATRIST)
        );
        Qualification[] types = Record.Qualification.values();
        for (Qualification type : types) {
            model.addAttribute(type.toString().toLowerCase(),
                    filterByType(records, type));
        }


    }
    @ModelAttribute(name = "recordPatients")
    public RecordPatients recordPatients() {
        return new RecordPatients();
    }

    @ModelAttribute(name = "patient")
    public Patient patient() {
        return new Patient();
    }

    @GetMapping
    public String showDesignForm() {
        return "design";
    }

    @PostMapping
    public String processPatient(Patient patient,
                              @ModelAttribute RecordPatients recordPatients) {
        recordPatients.addPatient(patient);
        log.info("Patient recorded: {}", patient);
        return "redirect:/orders/current";
    }

    private Iterable<Record> filterByType(
            List<Record> records, Qualification type) {
        return records
                .stream()
                .filter(x -> x.getQualification().equals(type))
                .collect(Collectors.toList());
    }
}
