package com.example.lab2_app.model;

import lombok.Data;

import java.util.List;

@Data
public class Patient {

    private String name;
    private String surname;
    private int age;
    private String phoneNumber;
    private String email;
    private List<Record> recordList;


}
