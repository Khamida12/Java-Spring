package com.example.controller;

import com.example.model.Client;
import com.example.repo.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CheckUpController {

    @Autowired
    private ClientRepository clientRepository;

    @GetMapping("/check")
    public String checkUpMain(Model model){
        Iterable<Client> clients = clientRepository.findAll();
        model.addAttribute("clients", clients);
        return "check-main";
    }

    @GetMapping("/check/add")
    public String checkUpAdd(Model model){
        return "check-add";
    }

    @PostMapping("/check/add")
    public String checkUpPostAdd(@RequestParam String firstName, @RequestParam String lastName, @RequestParam String middleName,
                                 @RequestParam int age, @RequestParam String email, @RequestParam String phone, @RequestParam String time, Model model){
        Client client = new Client(firstName, lastName, middleName, age, email, phone, time);
        clientRepository.save(client);
        return "redirect:/check";
    }
}
